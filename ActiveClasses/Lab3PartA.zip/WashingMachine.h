#include "rt.h"


class WashingMachine : public ActiveClass
{

	// put any attributes and member functions here that you like 
	// just like any other class along with any constructors and destructors

private:

	int MyNumber;

	//  Must override main() inherited from ActiveClass. The base class constructor will then
	//	create a thread execute main()
	int main(void);

public:
	WashingMachine(int _MyNumber) { MyNumber = _MyNumber; }
};
