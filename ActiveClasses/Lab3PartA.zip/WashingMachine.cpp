#include "rt.h"
#include "WashingMachine.h"

//
//	To create an active class with its own thread running through it. Derive a new class
//	from the base class 'ActiveClass' and then you MUST override the inherited base class function int main(void)
//	if you do not override main() with your own function it will not compile since the class will be abstract
//
//	Note that all active classes are created in the SUSPENDED state to avoid races between the constructor for the class
//	and the kernel which otherwise might try to run a thread through an incompleted constructed class object
//
//	Therefore you must forcible Resume() the class to allow its thread to run.
//

int WashingMachine::main(void)
{

	//	for (int i = 0; i < 5; i++) {
	//		cout << "I am an ActiveClass1 Object/Thread. My Data is " << MyNumber << ".....\n";
	//		SLEEP(400);
	//	}

	while (1) {
		printf("WM #%d: Ready \n", MyNumber);
		SLEEP(400);
		printf("WM #%d: IDLE \n", MyNumber);
		//cout << "WM #" << MyNumber << ": IDLE\n";
		SLEEP(400);
		printf("WM #%d: FILLING \n", MyNumber);
		//cout << "WM #" << MyNumber << ": FILLING\n";
		SLEEP(400);
		printf("WM #%d: WASHING \n", MyNumber);
		//cout << "WM #" << MyNumber << ": WASHING\n";
		SLEEP(400);
		printf("WM #%d: DRAINING \n", MyNumber);
		//cout << "WM #" << MyNumber << ": DRAINING\n";
		SLEEP(400);
		printf("WM #%d: SPINNING \n", MyNumber);
		//cout << "WM #" << MyNumber << ": SPINNING\n";
		SLEEP(400);

		return 0;
	}
}


//
//	The program main()
//
