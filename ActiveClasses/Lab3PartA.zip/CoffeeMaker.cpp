#include "rt.h"
#include "CoffeeMaker.h"

//
//	To create an active class with its own thread running through it. Derive a new class
//	from the base class 'ActiveClass' and then you MUST override the inherited base class function int main(void)
//	if you do not override main() with your own function it will not compile since the class will be abstract
//
//	Note that all active classes are created in the SUSPENDED state to avoid races between the constructor for the class
//	and the kernel which otherwise might try to run a thread through an incompleted constructed class object
//
//	Therefore you must forcible Resume() the class to allow its thread to run.
//

int CoffeeMaker::main(void)
{

//	for (int i = 0; i < 5; i++) {
//		cout << "I am an ActiveClass1 Object/Thread. My Data is " << MyNumber << ".....\n";
//		SLEEP(400);
//	}

	while (1) {
		printf("CM #%d: Ready \n", MyNumber);
		//cout << "CM #" << MyNumber << " Ready\n";
		SLEEP(400);
		printf("CM #%d: BOIL WATER\n", MyNumber);
		//cout << "CM #" <<MyNumber << ": BOIL WATER\n";
		SLEEP(400);
		printf("CM #%d: ADD COFFEE \n", MyNumber);
		//cout << "CM #" << MyNumber << ": ADD COFFEE\n";
		SLEEP(400);
		printf("CM #%d: ADD WATER \n", MyNumber);
		//cout << "CM #" << MyNumber << ": ADD MILK\n";
		SLEEP(400);
		printf("CM #%d: DISPENSE\n", MyNumber);
		//cout << "CM #" << MyNumber << ": DISPENSE\n";
		SLEEP(400);
		return 0;
	}
}


//
//	The program main()
//
